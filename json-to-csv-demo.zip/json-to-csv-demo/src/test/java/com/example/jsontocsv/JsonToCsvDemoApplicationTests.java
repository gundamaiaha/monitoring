package com.example.jsontocsv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonToCsvDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
